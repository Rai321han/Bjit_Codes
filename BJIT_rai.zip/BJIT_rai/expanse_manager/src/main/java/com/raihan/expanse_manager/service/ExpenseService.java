package com.raihan.expanse_manager.service;

import com.raihan.expanse_manager.dto.requestDto.ExpenseRequestDto;
import com.raihan.expanse_manager.entity.ExpenseEntity;
import com.raihan.expanse_manager.repository.ExpenseRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExpenseService {
    private final ExpenseRepository expenseRepository;

    public ExpenseService(ExpenseRepository expenseRepository) {
        this.expenseRepository = expenseRepository;
    }

    public String createExpense(ExpenseRequestDto requestDto) {
        if(requestDto != null) {
            ExpenseEntity expanse = new ExpenseEntity();
            expanse.setExpenseCategory(requestDto.getExpenseCategory());
            expanse.setExpenseName(requestDto.getExpenseName());
            expanse.setDescription(requestDto.getDescription());
            expanse.setDate(requestDto.getDate());
            expanse.setAmount(requestDto.getAmount());
            expenseRepository.save(expanse);
            return "Expense Created";
        }
        else return "Unable to create expense entity!";
    }
    public List<ExpenseEntity> getAllExpense() {
        return expenseRepository.findAll();
    }
}
