package com.raihan.expanse_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpanseManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
